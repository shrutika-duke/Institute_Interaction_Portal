package com.app.pojos;

public enum UserRole {
ADMIN,USER
}
